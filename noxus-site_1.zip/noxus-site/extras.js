(function () {
  'use strict';

  var root = document.documentElement;
  root.classList.add('js');
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  /* ---------- theme toggle ---------- */
  var themeBtn = $('theme');
  try {
    var saved = localStorage.getItem('noxus-theme');
    if (saved === 'light' || saved === 'dark') root.setAttribute('data-theme', saved);
  } catch (e) {}
  themeBtn.addEventListener('click', function () {
    var cur = root.getAttribute('data-theme');
    if (!cur) cur = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    var next = cur === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('noxus-theme', next); } catch (e) {}
  });

  /* ---------- scroll progress ---------- */
  function onScroll() {
    var max = root.scrollHeight - window.innerHeight;
    root.style.setProperty('--p', max > 0 ? Math.min(1, window.scrollY / max).toFixed(4) : 0);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- active nav link ---------- */
  var links = {};
  Array.prototype.forEach.call(document.querySelectorAll('[data-nav]'), function (a) { links[a.getAttribute('data-nav')] = a; });
  if ('IntersectionObserver' in window) {
    var navIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          Object.keys(links).forEach(function (k) { links[k].classList.toggle('active', k === en.target.id); });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    Object.keys(links).forEach(function (id) { var s = $(id); if (s) navIO.observe(s); });
  }

  /* ---------- reveal on scroll (always ends visible) ---------- */
  var revealEls = Array.prototype.slice.call(document.querySelectorAll('.reveal'));
  function showAll() { revealEls.forEach(function (n) { n.classList.add('in'); }); }
  if (reduce || !('IntersectionObserver' in window)) {
    showAll();
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px' });
    revealEls.forEach(function (n) { io.observe(n); });
    setTimeout(showAll, 4000);
  }

  /* ---------- spotlight on cards ---------- */
  document.addEventListener('pointermove', function (e) {
    var t = e.target.closest && e.target.closest('.svc, .panel');
    if (!t) return;
    var r = t.getBoundingClientRect();
    t.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    t.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });

  /* ---------- hero camera rotation ---------- */
  var CAMS = [
    { name: 'CAM 01 · FRONT ENTRANCE', zone: 'ZONE A · CLEAR', tab: 'Entrance' },
    { name: 'CAM 02 · SERVER ROOM', zone: 'LINK 4 · CHECK PORT', tab: 'Network' },
    { name: 'CAM 03 · HOME GATE + BOOM BARRIER', zone: 'GATE CLOSED · VEHICLE AT BARRIER', tab: 'Gates' },
    { name: 'CAM 04 · HOME CCTV', zone: 'FRONT DOOR · MOTION', tab: 'Home' }
  ];
  var groups = Array.prototype.slice.call(document.querySelectorAll('.scene .cam'));
  var camTabs = $('camtabs'), camName = $('cam-name'), camZone = $('cam-zone'), feed = $('feed');
  var camIndex = 0, timer = null, paused = false;

  function setCam(i) {
    camIndex = i;
    groups.forEach(function (g, k) { g.classList.toggle('on', k === i); });
    camName.textContent = CAMS[i].name;
    camZone.textContent = CAMS[i].zone;
    Array.prototype.forEach.call(camTabs.children, function (b, k) { b.setAttribute('aria-selected', k === i ? 'true' : 'false'); });
  }
  CAMS.forEach(function (c, i) {
    var b = el('button', 'tab', c.tab);
    b.type = 'button';
    b.setAttribute('role', 'tab');
    b.addEventListener('click', function () { setCam(i); restart(); });
    camTabs.appendChild(b);
  });
  function restart() {
    clearInterval(timer);
    if (reduce) return;
    timer = setInterval(function () { if (!paused) setCam((camIndex + 1) % CAMS.length); }, 5000);
  }
  feed.addEventListener('pointerenter', function () { paused = true; });
  feed.addEventListener('pointerleave', function () { paused = false; });
  camTabs.addEventListener('focusin', function () { paused = true; });
  camTabs.addEventListener('focusout', function () { paused = false; });
  setCam(0); restart();

  /* ---------- service finder ---------- */
  var T = {
    cctv: 'CCTV installation and maintenance',
    truck: 'Truck and bus camera installation',
    access: 'Access control systems',
    door: 'Video door phones and doorbells',
    lock: 'Smart locks and door locks',
    alarm: 'Alarm and intrusion detection',
    barrier: 'Boom barrier systems',
    perimeter: 'Perimeter protection',
    net: 'Office networking',
    server: 'Network and server installation',
    home: 'Smart home automation',
    office: 'Office automation',
    industrial: 'Industrial automation'
  };
  var BY_PLACE = {
    home: [T.cctv, T.door, T.lock, T.home],
    shop: [T.cctv, T.access, T.net, T.office],
    factory: [T.cctv, T.perimeter, T.barrier, T.industrial],
    vehicle: [T.truck]
  };
  var AUTO_BY_PLACE = { home: T.home, shop: T.office, factory: T.industrial };
  var picksEl = $('picks'), picks = [];

  function checkedValue(name) {
    var n = document.querySelector('input[name="' + name + '"]:checked');
    return n ? n.value : '';
  }
  function checkedValues(name) {
    return Array.prototype.map.call(document.querySelectorAll('input[name="' + name + '"]:checked'), function (n) { return n.value; });
  }
  function add(list, t) { if (t && list.indexOf(t) < 0) list.push(t); }

  function suggest() {
    var place = checkedValue('place') || 'home';
    var goals = checkedValues('goal');
    var out = [];
    if (place === 'vehicle') {
      add(out, T.truck);
    } else if (!goals.length) {
      BY_PLACE[place].forEach(function (t) { add(out, t); });
    } else {
      goals.forEach(function (g) {
        if (g === 'watch') add(out, T.cctv);
        if (g === 'entry') {
          if (place === 'home') { add(out, T.door); add(out, T.lock); }
          else if (place === 'shop') { add(out, T.access); add(out, T.lock); }
          else { add(out, T.access); add(out, T.barrier); }
        }
        if (g === 'network') { add(out, T.net); add(out, T.server); }
        if (g === 'auto') add(out, AUTO_BY_PLACE[place]);
        if (g === 'alarm') { add(out, T.alarm); if (place === 'factory') add(out, T.perimeter); }
      });
    }
    picks = out;
    picksEl.textContent = '';
    out.forEach(function (t) { picksEl.appendChild(el('li', null, t)); });
  }
  Array.prototype.forEach.call(document.querySelectorAll('.finder input'), function (i) { i.addEventListener('change', suggest); });
  suggest();

  $('finder-go').addEventListener('click', function () {
    var placeLabel = { home: 'Home or flat', shop: 'Shop or office', factory: 'Factory or warehouse', vehicle: 'Trucks or buses' }[checkedValue('place')] || '';
    var sel = $('f-svc');
    if (picks.length) sel.value = picks[0];
    $('f-msg').value = 'Location: ' + placeLabel + '\nI am interested in: ' + picks.join(', ') + '.';
    $('contact').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
    setTimeout(function () { $('f-name').focus({ preventScroll: true }); }, 500);
  });

  /* ---------- FAQ (answers come from the company's own terms and poster) ---------- */
  var DEFAULT_FAQ = [
    ['Do you offer a free site visit?', 'Yes. Our experts visit your site, do a survey and give you a professional digital layout plan, free of charge. You also get a free site inspection and estimation.'],
    ['What support and warranty do I get?', 'We offer 24/7 support. After installation you get one year of free service support (it does not cover replacement materials, extra equipment or damage from outside factors). Installation workmanship has a 7-month warranty from the completion date, and equipment carries the manufacturer’s warranty where applicable.'],
    ['Can I watch my cameras on my phone?', 'Yes. Remote viewing needs a stable internet connection and compatible router and network settings, and it depends on your mobile device being compatible.'],
    ['How long are recordings kept?', 'It depends on the number of cameras, hard disk size, recording quality, frame rate and settings. We cannot promise a fixed period unless we agree it in writing.'],
    ['Do you install cameras in trucks and buses?', 'Yes. Tell us the vehicle type and what you want to monitor, and we will advise on the setup.'],
    ['How do payments work?', 'The advance is not refundable once materials have been ordered for your project. The balance is due when the installation is finished and the system is handed over. Quotations are valid for 15 days.']
  ];
  var faqList = $('faq-list');
  function renderFaq(list) {
    faqList.textContent = '';
    list.forEach(function (qa, i) {
      var d = el('details', 'qa');
      if (i === 0) d.open = true;
      d.appendChild(el('summary', null, qa[0]));
      d.appendChild(el('p', null, qa[1]));
      faqList.appendChild(d);
    });
  }
  renderFaq(DEFAULT_FAQ);
  fetch('content/faq.json', { cache: 'no-cache' })
    .then(function (r) { if (!r.ok) throw new Error('none'); return r.json(); })
    .then(function (d) {
      var list = (d && Array.isArray(d.items) ? d.items : [])
        .filter(function (x) { return x && typeof x.question === 'string' && typeof x.answer === 'string' && x.question; })
        .map(function (x) { return [x.question.slice(0, 160), x.answer.slice(0, 1200)]; });
      if (list.length) renderFaq(list);
    })
    .catch(function () {});
})();
