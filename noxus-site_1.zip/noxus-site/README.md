# NOXUS SYSTEMS website

## Deploy on Netlify
1. Drag this whole folder into Netlify (Sites > Add new site > Deploy manually).
2. Add your domain and set the GoDaddy DNS records as described in chat.
3. Turn on HTTPS in Domain management.

## Receive enquiries
The enquiry form uses Netlify Forms.
1. After the first deploy, open your site in Netlify > Forms. You will see "enquiry".
2. Forms > Form notifications > Add notification > Email notification.
   Use office.noxussystem@gmail.com.
3. Every enquiry is also stored in the Forms tab.
Spam is blocked by a hidden honeypot field plus Netlify's spam filter.

## Admin panel
See ADMIN-SETUP.md. After setup, you edit text, services, FAQ, areas and photos at /admin.

## Add project photos (manual way)
1. Put photos in the `images` folder. Use names with letters, numbers, dots, dashes
   only, e.g. `shop-cctv-kottayam.jpg`. Resize to about 1600px wide first.
2. Edit `content/projects.json`, for example:

```json
{"items": [
  { "title": "CCTV for a retail shop", "place": "Kottayam", "category": "CCTV", "image": "images/shop-cctv-kottayam.jpg" },
  { "title": "Office network and Wi-Fi", "place": "Changanassery", "category": "Networking", "image": "images/office-network.jpg" }
]}
```
3. Upload the folder to Netlify again (Deploys > drag the folder).
The gallery and its category filters update automatically. Do not include photos that
show customer names, addresses or live footage.

## Add or change services
Services are in `content/services.json` (or use the admin panel).

## Security notes
- No third-party scripts. Only your own files and Google Fonts are allowed by the
  Content Security Policy in `netlify.toml`.
- Security headers (HSTS, no framing, no sniffing, strict permissions) are set in `netlify.toml`.
- Photo names in `projects.json` are checked before use, and all text is inserted safely.
- Protect your Netlify and GoDaddy accounts with two-step login and strong, unique passwords.
  That matters more than anything in the code.

## Interactive features (extras.js)
- Hero camera views rotate every 5 seconds (they stop on hover and for reduced-motion users).
- "Find your setup" suggests services and fills the enquiry form. Edit the lists near the top of the finder code in `extras.js`.
- FAQ answers are in `extras.js` (search for `var FAQ`).
- Light/dark switch remembers the visitor's choice.
