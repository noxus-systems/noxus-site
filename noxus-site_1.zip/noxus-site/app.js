(function () {
  'use strict';

  var PHONE_WA = '918848150659';
  var FALLBACK_CATS = ['security', 'network', 'auto'];
  var NS = 'http://www.w3.org/2000/svg';

  /* ---------- Service data (edit here to add or change services) ---------- */
  var CATEGORIES = [
    { id: 'all', label: 'All services' },
    { id: 'security', label: 'Security' },
    { id: 'network', label: 'Networking & servers' },
    { id: 'auto', label: 'Automation & smart' }
  ];

  var ICONS = {
    cctv: '<path d="M6 14h30v14H6z"/><path d="M36 18l8-4v16l-8-4"/><path d="M14 28v10h12"/><circle cx="21" cy="21" r="3"/>',
    access: '<rect x="10" y="20" width="28" height="20" rx="2"/><path d="M16 20v-6a8 8 0 0 1 16 0v6"/><circle cx="24" cy="30" r="3"/>',
    door: '<rect x="14" y="6" width="20" height="36" rx="3"/><circle cx="24" cy="17" r="4"/><circle cx="24" cy="32" r="2.5"/><path d="M19 26h10"/>',
    alarm: '<path d="M24 6l16 6v10c0 10-7 17-16 20C15 39 8 32 8 22V12z"/><path d="M24 17v9"/><circle cx="24" cy="31" r="1.4"/>',
    network: '<rect x="18" y="6" width="12" height="9" rx="1"/><rect x="5" y="33" width="12" height="9" rx="1"/><rect x="31" y="33" width="12" height="9" rx="1"/><path d="M24 15v9M11 33v-9h26v9"/>',
    server: '<rect x="8" y="8" width="32" height="10" rx="2"/><rect x="8" y="21" width="32" height="10" rx="2"/><rect x="8" y="34" width="32" height="8" rx="2"/><circle cx="14" cy="13" r="1.4"/><circle cx="14" cy="26" r="1.4"/>',
    support: '<path d="M8 28v-6a16 16 0 0 1 32 0v6"/><rect x="6" y="26" width="8" height="12" rx="2"/><rect x="34" y="26" width="8" height="12" rx="2"/><path d="M38 38c0 4-6 5-12 5"/>',
    office: '<rect x="6" y="10" width="36" height="24" rx="2"/><path d="M18 42h12M24 34v8"/><path d="M13 27l6-6 5 4 8-9"/>',
    home: '<path d="M6 24L24 8l18 16"/><path d="M12 21v19h24V21"/><path d="M19 32a7 7 0 0 1 10 0M16 28a12 12 0 0 1 16 0"/><circle cx="24" cy="35" r="1.3"/>',
    smart: '<circle cx="24" cy="24" r="6"/><path d="M24 6v6M24 36v6M6 24h6M36 24h6M11 11l4 4M33 33l4 4M37 11l-4 4M15 33l-4 4"/>',
    custom: '<path d="M24 8v32M8 24h32"/><circle cx="24" cy="24" r="16"/>',
    lock: '<rect x="14" y="6" width="14" height="36" rx="2"/><circle cx="21" cy="16" r="3"/><path d="M28 28h10a3 3 0 0 1 0 6H28"/>',
    barrier: '<rect x="6" y="22" width="10" height="16" rx="1"/><rect x="16" y="24" width="28" height="5"/><path d="M24 24v5M32 24v5M40 24v5"/>',
    fence: '<path d="M8 40V18l3-4 3 4v22M20 40V18l3-4 3 4v22M32 40V18l3-4 3 4v22"/><path d="M4 26h40M4 34h40"/>',
    factory: '<path d="M6 40V24l10 6V24l10 6V24l10 6V8h6v32z"/><path d="M12 40v-4M22 40v-4M32 40v-4"/>',
    truck: '<path d="M4 32V14h24v18"/><path d="M28 20h8l8 8v4H28"/><circle cx="14" cy="34" r="4"/><circle cx="36" cy="34" r="4"/>',
    amc: '<path d="M24 6l16 6v10c0 10-7 17-16 20C15 39 8 32 8 22V12z"/><path d="M17 24l5 5 9-10"/>'
  };

  var SERVICES = [
    { cat: 'security', icon: 'cctv', title: 'CCTV installation and maintenance',
      items: ['IP camera and HD camera systems', 'Remote viewing on your phone', 'Recorders and surveillance storage', 'Maintenance and troubleshooting'],
      benefit: 'See your property any time, and keep the footage safe.' },
    { cat: 'security', icon: 'truck', title: 'Truck and bus camera installation',
      items: ['Camera systems for trucks and buses', 'Installation inside the vehicle', 'Recording and storage on board', 'Maintenance and troubleshooting'],
      benefit: 'Keep watch over your vehicle, your driver and your cargo.' },
    { cat: 'security', icon: 'access', title: 'Access control systems',
      items: ['Biometric attendance systems', 'Fingerprint, card and face access', 'Door controllers and electric locks', 'Maintenance and support'],
      benefit: 'Decide who comes in, and record when they do.' },
    { cat: 'security', icon: 'door', title: 'Video door phones and doorbells',
      items: ['Video door phones for homes and flats', 'Smart video doorbells', 'Gate and entrance intercoms', 'Installation and repair'],
      benefit: 'See and speak to visitors before you open the door.' },
    { cat: 'security', icon: 'lock', title: 'Smart locks and door locks',
      items: ['Smart door locks for homes and offices', 'Fingerprint, PIN, card and app access', 'Installation and set-up', 'Support after installation'],
      benefit: 'Lock and unlock without carrying a key.' },
    { cat: 'security', icon: 'alarm', title: 'Alarm and intrusion detection',
      items: ['Door, window and motion sensors', 'Sirens and alert systems', 'Smart security solutions', 'Integration with cameras'],
      benefit: 'Get warned the moment something is wrong.' },
    { cat: 'security', icon: 'barrier', title: 'Boom barrier systems',
      items: ['Automatic boom barriers', 'Vehicle entry control for gates and parking', 'Installation and maintenance'],
      benefit: 'Control which vehicles enter, and when.' },
    { cat: 'security', icon: 'fence', title: 'Perimeter protection',
      items: ['Boundary and fence security', 'Cameras and sensors along the perimeter', 'Planned after a site survey'],
      benefit: 'Know about trouble before it reaches the building.' },
    { cat: 'network', icon: 'network', title: 'Office networking',
      items: ['Structured cabling', 'LAN and Wi-Fi installation', 'Router and switch configuration', 'Network maintenance'],
      benefit: 'A tidy, reliable network for your team and your cameras.' },
    { cat: 'network', icon: 'server', title: 'Network and server installation',
      items: ['Server setup and configuration', 'File sharing and user access', 'Backup arrangements', 'Ongoing server upkeep'],
      benefit: 'Keep your office data in one place, organised and backed up.' },
    { cat: 'network', icon: 'amc', title: 'IT infrastructure and AMC',
      items: ['Annual maintenance contracts (AMC)', 'Regular maintenance visits', 'Troubleshooting computers and networks', 'Software updates and upgrades'],
      benefit: 'Fewer interruptions, and someone to call when they happen.' },
    { cat: 'auto', icon: 'home', title: 'Smart home automation',
      items: ['Lighting and appliance control', 'Control by phone or voice', 'Smart locks and video door phones', 'Cameras linked to your home system'],
      benefit: 'Control your home from anywhere.' },
    { cat: 'auto', icon: 'office', title: 'Office automation',
      items: ['Attendance and access working together', 'Shared printers and file storage', 'Connected systems for staff', 'Setup and handover'],
      benefit: 'Less manual work and a smoother day in the office.' },
    { cat: 'auto', icon: 'factory', title: 'Industrial automation',
      items: ['Automation for factories and workshops', 'Sensors, controllers and panels', 'Installation and commissioning', 'Maintenance and support'],
      benefit: 'More control over how your site runs.' },
    { cat: 'auto', icon: 'smart', title: 'Smart security and automation',
      items: ['Cameras, sensors and alerts working together', 'Scenes and schedules', 'Remote control and monitoring', 'Planned around your space'],
      benefit: 'Security that reacts, not just records.' },
    { cat: 'auto', icon: 'custom', title: 'Something else?', custom: true,
      items: ['Automation covers many things', 'Tell us what you want to control or connect', 'We will advise what is possible'],
      benefit: 'Describe your idea and we will suggest a setup.' }
  ];

  var CAT_LABEL = { security: 'Security', network: 'Networking', auto: 'Automation' };

  /* ---------- helpers ---------- */
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function waLink(text) {
    return 'https://wa.me/' + PHONE_WA + '?text=' + encodeURIComponent(text);
  }
  function icon(name) {
    var s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 48 48');
    s.setAttribute('fill', 'none');
    s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '2.4');
    s.setAttribute('stroke-linecap', 'round');
    s.setAttribute('stroke-linejoin', 'round');
    s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'ico');
    s.innerHTML = ICONS[name] || ''; /* static, trusted markup only */
    return s;
  }

  /* ---------- clock, year, WhatsApp links ---------- */
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  var clock = $('clock');
  function tick() {
    var d = new Date();
    clock.textContent = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' +
      pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }
  tick(); setInterval(tick, 1000);
  $('yr').textContent = new Date().getFullYear();
  function setWaLinks() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-wa]'), function (a) {
      a.href = waLink(a.getAttribute('data-wa'));
    });
  }
  setWaLinks();

  /* ---------- services ---------- */
  var tabs = $('tabs'), grid = $('svc-grid'), select = $('f-svc');
  var activeCat = 'all';

  function renderTabs() {
    tabs.textContent = '';
    CATEGORIES.forEach(function (c) {
      var b = el('button', 'tab', c.label);
      b.type = 'button';
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', c.id === activeCat ? 'true' : 'false');
      b.addEventListener('click', function () { activeCat = c.id; renderTabs(); renderServices(); });
      tabs.appendChild(b);
    });
  }

  function chooseService(title) {
    select.value = title;
    $('contact').scrollIntoView({ behavior: 'smooth' });
    setTimeout(function () { $('f-name').focus({ preventScroll: true }); }, 500);
  }

  function renderServices() {
    grid.textContent = '';
    SERVICES.forEach(function (s) {
      if (activeCat !== 'all' && s.cat !== activeCat) return;
      var card = el('article', 'svc' + (s.custom ? ' custom' : ''));
      var top = el('div', 'top');
      top.appendChild(icon(s.icon));
      top.appendChild(el('span', 'tag', CAT_LABEL[s.cat]));
      card.appendChild(top);
      card.appendChild(el('h3', null, s.title));
      var ul = el('ul');
      s.items.forEach(function (i) { ul.appendChild(el('li', null, i)); });
      card.appendChild(ul);
      card.appendChild(el('p', 'benefit', s.benefit));
      var b = el('button', 'btn small', 'Enquire about this');
      b.type = 'button';
      b.addEventListener('click', function () { chooseService(s.title); });
      card.appendChild(b);
      grid.appendChild(card);
    });
  }

  function buildOptions() {
    var keep = select.value;
    select.textContent = '';
    SERVICES.forEach(function (s) {
      var o = el('option', null, s.title);
      o.value = s.title;
      select.appendChild(o);
    });
    if (keep) select.value = keep;
  }
  buildOptions(); renderTabs(); renderServices();

  /* ---------- editable content (content/*.json, edited from /admin) ---------- */
  function getJSON(path) {
    return fetch(path, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error('none'); return r.json(); });
  }
  function str(v, max) { return typeof v === 'string' ? v.slice(0, max || 400) : ''; }

  getJSON('content/services.json').then(function (d) {
    var list = (d && Array.isArray(d.items) ? d.items : []).map(function (s) {
      var pts = Array.isArray(s.points) ? s.points.map(function (p) { return str(p, 140); }).filter(Boolean) : [];
      return {
        cat: FALLBACK_CATS.indexOf(s.category) >= 0 ? s.category : 'security',
        icon: ICONS[s.icon] ? s.icon : 'custom',
        title: str(s.title, 90), items: pts.slice(0, 8), benefit: str(s.benefit, 200), custom: !!s.custom
      };
    }).filter(function (s) { return s.title; });
    if (list.length) { SERVICES = list; buildOptions(); renderServices(); }
  }).catch(function () {});

  getJSON('content/areas.json').then(function (d) {
    var ul = $('areas-list');
    var list = d && Array.isArray(d.items) ? d.items.map(function (a) { return str(a, 60); }).filter(Boolean) : [];
    if (!ul || !list.length) return;
    ul.textContent = '';
    list.forEach(function (a) { ul.appendChild(el('li', null, a)); });
  }).catch(function () {});

  getJSON('content/site.json').then(function (s) {
    if (!s || typeof s !== 'object') return;
    Array.prototype.forEach.call(document.querySelectorAll('[data-site]'), function (n) {
      var v = s[n.getAttribute('data-site')];
      if (typeof v === 'string' && v.trim()) n.textContent = v.slice(0, 600);
    });
    var wa = str(s.whatsapp, 20).replace(/\D/g, '');
    if (wa.length >= 10) { PHONE_WA = wa; setWaLinks(); var call = $('call-btn'); if (call) call.href = 'tel:+' + wa; }
    var mail = str(s.email, 120);
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) { var mb = $('mail-btn'); if (mb) mb.href = 'mailto:' + mail; }
    var maps = str(s.maps_url, 300);
    if (/^https:\/\/(maps\.app\.goo\.gl|www\.google\.com\/maps|goo\.gl\/maps|maps\.google\.com)\//.test(maps)) { var mp = $('map-btn'); if (mp) mp.href = maps; }
  }).catch(function () {});

  /* ---------- projects (loaded from projects.json) ---------- */
  var projGrid = $('proj-grid'), projFilters = $('proj-filters');
  var FALLBACK_TILES = ['CCTV installation', 'Office network', 'Access control', 'Smart home'];
  var projects = [], projCat = 'all';

  function safeImage(src) {
    return typeof src === 'string' && /^images\/[A-Za-z0-9._\-]+\.(jpe?g|png|webp|avif)$/i.test(src);
  }

  function openLightbox(p) {
    var box = el('div', 'lightbox');
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-label', p.title);
    var img = el('img');
    img.src = p.image; img.alt = p.title;
    var cap = el('p', null, p.title + (p.place ? ' · ' + p.place : ''));
    var close = el('button', 'btn small', 'Close');
    close.type = 'button';
    function done() { document.removeEventListener('keydown', onKey); box.remove(); }
    function onKey(e) { if (e.key === 'Escape') done(); }
    close.addEventListener('click', done);
    box.addEventListener('click', function (e) { if (e.target === box) done(); });
    document.addEventListener('keydown', onKey);
    box.appendChild(img); box.appendChild(cap); box.appendChild(close);
    document.body.appendChild(box);
    close.focus();
  }

  function renderProjects() {
    projGrid.textContent = '';
    projFilters.textContent = '';
    if (!projects.length) {
      $('proj-note').textContent = 'Project photos are being added. Ask us for references on request.';
      FALLBACK_TILES.forEach(function (t) {
        var d = el('div', 'tile');
        d.appendChild(el('span', null, 'Photo coming soon'));
        d.appendChild(el('b', null, t));
        projGrid.appendChild(d);
      });
      return;
    }
    var cats = ['all'];
    projects.forEach(function (p) { if (p.category && cats.indexOf(p.category) < 0) cats.push(p.category); });
    if (cats.length > 2) {
      cats.forEach(function (c) {
        var b = el('button', 'tab', c === 'all' ? 'All' : c);
        b.type = 'button';
        b.setAttribute('aria-pressed', c === projCat ? 'true' : 'false');
        if (c === projCat) b.setAttribute('aria-selected', 'true');
        b.addEventListener('click', function () { projCat = c; renderProjects(); });
        projFilters.appendChild(b);
      });
    }
    projects.forEach(function (p) {
      if (projCat !== 'all' && p.category !== projCat) return;
      var f = el('figure', 'proj');
      var btn = el('button');
      btn.type = 'button';
      btn.setAttribute('aria-label', 'Enlarge photo: ' + p.title);
      var img = el('img');
      img.src = p.image; img.alt = p.title; img.loading = 'lazy';
      btn.appendChild(img);
      btn.addEventListener('click', function () { openLightbox(p); });
      var cap = el('figcaption');
      cap.appendChild(el('b', null, p.title));
      if (p.place) cap.appendChild(el('span', null, p.place));
      f.appendChild(btn); f.appendChild(cap);
      projGrid.appendChild(f);
    });
  }

  fetch('content/projects.json', { cache: 'no-cache' })
    .then(function (r) { if (!r.ok) throw new Error('none'); return r.json(); })
    .then(function (data) {
      projects = (Array.isArray(data) ? data : (data && Array.isArray(data.items) ? data.items : []))
        .filter(function (p) { return p && typeof p.title === 'string' && safeImage(p.image); })
        .map(function (p) {
          return { title: p.title.slice(0, 80), place: typeof p.place === 'string' ? p.place.slice(0, 80) : '',
                   category: typeof p.category === 'string' ? p.category.slice(0, 40) : '', image: p.image };
        });
      renderProjects();
    })
    .catch(function () { projects = []; renderProjects(); });

  /* ---------- copy buttons ---------- */
  Array.prototype.forEach.call(document.querySelectorAll('.copy'), function (b) {
    b.addEventListener('click', function () {
      var node = $(b.getAttribute('data-target'));
      function flash(t) { b.textContent = t; setTimeout(function () { b.textContent = 'Copy'; }, 1600); }
      function fallback() {
        var r = document.createRange(); r.selectNodeContents(node);
        var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); flash('Selected');
      }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(node.textContent).then(function () { flash('Copied'); }, fallback);
        } else { fallback(); }
      } catch (e) { fallback(); }
    });
  });

  /* ---------- enquiry form ---------- */
  var form = $('enq'), status = $('status'), submit = $('submit');

  function show(kind, text, linkText, linkHref) {
    status.hidden = false;
    status.className = 'status ' + kind;
    status.textContent = text + ' ';
    if (linkHref) {
      var a = el('a', null, linkText);
      a.href = linkHref; a.target = '_blank'; a.rel = 'noopener';
      status.appendChild(a);
    }
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = $('f-name').value.trim();
    var phone = $('f-phone').value.trim();
    var digits = phone.replace(/\D/g, '');
    if (!name) { show('err', 'Please enter your name.'); $('f-name').focus(); return; }
    if (digits.length < 8 || digits.length > 15 || !/^[0-9+\-\s()]+$/.test(phone)) {
      show('err', 'Please enter a valid phone number.'); $('f-phone').focus(); return;
    }
    var email = $('f-email').value.trim();
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      show('err', 'That email address does not look right.'); $('f-email').focus(); return;
    }
    var body = new URLSearchParams(new FormData(form)).toString();
    submit.disabled = true; submit.textContent = 'Sending…';

    var wa = waLink('Hello NOXUS SYSTEMS, I would like to make an enquiry.\nName: ' + name + '\nPhone: ' + phone +
      '\nService: ' + select.value + ($('f-msg').value.trim() ? '\nDetails: ' + $('f-msg').value.trim() : ''));

    fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body })
      .then(function (r) {
        if (!r.ok) throw new Error('failed');
        form.reset();
        show('ok', 'Thank you. Your enquiry has been sent and we will contact you soon.');
      })
      .catch(function () {
        show('err', 'We could not send the form. Please send it on WhatsApp instead:', 'Open WhatsApp', wa);
      })
      .then(function () { submit.disabled = false; submit.textContent = 'Send enquiry'; });
  });
})();
